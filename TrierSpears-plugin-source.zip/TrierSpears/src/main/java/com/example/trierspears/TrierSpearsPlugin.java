package com.example.trierspears;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Vector;
import org.bukkit.command.*;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.*;

public class TrierSpearsPlugin extends JavaPlugin implements Listener, CommandExecutor {
    private final NamespacedKey itemKey = new NamespacedKey(this, "trier_spear");
    private final NamespacedKey tierKey = new NamespacedKey(this, "trier_tier");
    private final Map<UUID, Integer> kills = new HashMap<>();
    private final Map<UUID, Long> slowCooldown = new HashMap<>();
    private final Map<UUID, Long> dashCooldown = new HashMap<>();

    private enum Tier {
        WOOD("Wooden Trier", Material.WOODEN_SPEAR, 0, ChatColor.GRAY),
        STONE("Stone Trier", Material.STONE_SPEAR, 5, ChatColor.GRAY),
        COPPER("Copper Trier", Material.COPPER_SPEAR, 15, ChatColor.GOLD),
        IRON("Iron Trier", Material.IRON_SPEAR, 30, ChatColor.WHITE),
        GOLD("Golden Trier", Material.GOLDEN_SPEAR, 50, ChatColor.YELLOW),
        DIAMOND("Diamond Trier", Material.DIAMOND_SPEAR, 100, ChatColor.AQUA),
        EMERALD("Emerald Trier", Material.DIAMOND_SPEAR, 175, ChatColor.GREEN),
        NETHER("Nether Trier", Material.NETHERITE_SPEAR, 250, ChatColor.DARK_RED),
        GOD("God Trier", Material.NETHERITE_SPEAR, 500, ChatColor.LIGHT_PURPLE);
        final String display; final Material material; final int required; final ChatColor color;
        Tier(String d, Material m, int r, ChatColor c) { display=d; material=m; required=r; color=c; }
    }

    @Override public void onEnable() {
        saveDefaultConfig();
        for (String key : getConfig().getKeys(false)) {
            try { kills.put(UUID.fromString(key), getConfig().getInt(key)); } catch (Exception ignored) {}
        }
        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("trier")).setExecutor(this);
        for (Player p : Bukkit.getOnlinePlayers()) { ensureStarter(p); updateRank(p); }
        getLogger().info("TrierSpears enabled.");
    }
    @Override public void onDisable() { saveKills(); }

    private void saveKills() { for (var e : kills.entrySet()) getConfig().set(e.getKey().toString(), e.getValue()); saveConfig(); }
    private int getKills(Player p) { return kills.getOrDefault(p.getUniqueId(), 0); }
    private Tier tierFor(int count) { Tier result=Tier.WOOD; for (Tier t : Tier.values()) if (count>=t.required) result=t; return result; }
    private boolean isFractured(ItemStack item) { return item!=null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(itemKey, PersistentDataType.STRING) && "fractured".equals(item.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING)); }
    private String itemTier(ItemStack item) { if (item==null || !item.hasItemMeta()) return ""; return item.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING); }
    private ItemStack makeSpear(Tier tier) {
        ItemStack item = new ItemStack(tier.material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(tier.color + "§l" + tier.display);
        meta.setLore(List.of(ChatColor.GRAY + "Kill progression weapon", ChatColor.DARK_GRAY + "Tier: " + tier.display));
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, tier.name().toLowerCase());
        meta.getPersistentDataContainer().set(tierKey, PersistentDataType.INTEGER, tier.ordinal());
        if (tier == Tier.GOD) {
            meta.addEnchant(Enchantment.SHARPNESS, 5, true);
            meta.addEnchant(Enchantment.UNBREAKING, 3, true);
            meta.addEnchant(Enchantment.MENDING, 1, true);
            meta.addEnchant(Enchantment.KNOCKBACK, 2, true);
        }
        item.setItemMeta(meta); return item;
    }
    private ItemStack makeFractured() {
        ItemStack item = new ItemStack(Material.NETHERITE_SPEAR);
        ItemMeta meta=item.getItemMeta(); meta.setDisplayName(ChatColor.DARK_PURPLE+"§lThe Fractured");
        meta.setLore(List.of(ChatColor.RED+"One strike. One death.", ChatColor.DARK_GRAY+"Secret weapon"));
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, "fractured");
        meta.addEnchant(Enchantment.SHARPNESS, 5, true); meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        item.setItemMeta(meta); return item;
    }
    private void ensureStarter(Player p) {
        boolean has = p.getInventory().contains(Material.WOODEN_SPEAR) || hasTaggedSpear(p);
        if (!has && getKills(p)==0) p.getInventory().addItem(makeSpear(Tier.WOOD));
    }
    private boolean hasTaggedSpear(Player p) {
        for (ItemStack i : p.getInventory().getContents()) if (i!=null && i.hasItemMeta() && i.getItemMeta().getPersistentDataContainer().has(itemKey, PersistentDataType.STRING)) return true;
        return false;
    }
    private void giveCurrent(Player p) {
        Tier t=tierFor(getKills(p));
        // Replace the plugin's progression spear in main inventory, preserving other items.
        for (int slot=0; slot<p.getInventory().getSize(); slot++) {
            ItemStack old=p.getInventory().getItem(slot);
            if (old!=null && old.hasItemMeta() && old.getItemMeta().getPersistentDataContainer().has(itemKey, PersistentDataType.STRING) && !isFractured(old)) {
                p.getInventory().setItem(slot, makeSpear(t)); return;
            }
        }
        p.getInventory().addItem(makeSpear(t));
    }
    private void updateRank(Player p) {
        Scoreboard board=Bukkit.getScoreboardManager().getMainScoreboard();
        String teamName="trier_"+p.getUniqueId().toString().substring(0,8);
        Team team=board.getTeam(teamName); if(team==null) team=board.registerNewTeam(teamName);
        Tier tier=tierFor(getKills(p));
        team.setPrefix(tier.color+"["+tier.display+"] "); team.setSuffix(ChatColor.RESET+""); team.setOption(Team.Option.NAME_TAG_VISIBILITY, Team.OptionStatus.ALWAYS);
        if (!team.hasEntry(p.getName())) team.addEntry(p.getName());
        p.setScoreboard(board);
        p.setPlayerListName(tier.color+"["+tier.display+"] "+ChatColor.WHITE+p.getName());
    }
    @EventHandler public void onJoin(PlayerJoinEvent e) { ensureStarter(e.getPlayer()); updateRank(e.getPlayer()); }
    @EventHandler public void onDeath(PlayerDeathEvent e) {
        Player victim=e.getEntity(); Player killer=victim.getKiller();
        if (killer==null || killer.equals(victim)) return;
        int count=getKills(killer)+1; kills.put(killer.getUniqueId(), count); saveKills();
        Tier before=tierFor(count-1), after=tierFor(count);
        if (after!=before) {
            giveCurrent(killer); updateRank(killer);
            killer.sendMessage(ChatColor.GOLD+"✦ Tier unlocked: "+after.color+after.display+ChatColor.GOLD+"!");
            killer.playSound(killer.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1.15f);
        } else killer.sendMessage(ChatColor.GREEN+"PvP kill! "+ChatColor.YELLOW+count+ChatColor.GRAY+" total kills.");
    }
    @EventHandler public void onInteract(PlayerInteractEvent e) {
        if (e.getHand()!=org.bukkit.inventory.EquipmentSlot.HAND) return;
        Player p=e.getPlayer(); ItemStack item=e.getItem(); String tier=itemTier(item);
        if (!"god".equals(tier)) return;
        if (e.getAction().isRightClick() && p.isSneaking()) {
            e.setCancelled(true); activateSlow(p);
        }
    }
    private void activateSlow(Player owner) {
        long now=System.currentTimeMillis(); if (slowCooldown.getOrDefault(owner.getUniqueId(),0L)>now) { owner.sendMessage(ChatColor.RED+"Time Slow is cooling down."); return; }
        int affected=0;
        for (Player target : owner.getWorld().getPlayers()) {
            if (target.equals(owner) || target.getLocation().distanceSquared(owner.getLocation())>144) continue;
            target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 80, 5, true, true, true));
            target.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 80, 2, true, true, true));
            target.getWorld().spawnParticle(Particle.END_ROD, target.getLocation().add(0,1,0), 18, .4,.7,.4,.02);
            affected++;
        }
        slowCooldown.put(owner.getUniqueId(), now+15000);
        owner.sendMessage(ChatColor.LIGHT_PURPLE+"Time Slow! Affected "+affected+" nearby enemy player(s).");
        owner.getWorld().playSound(owner.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, .6f);
    }
    @EventHandler public void onSwap(PlayerSwapHandItemsEvent e) {
        Player p=e.getPlayer(); if (!"god".equals(itemTier(e.getMainHandItem()))) return;
        e.setCancelled(true); long now=System.currentTimeMillis();
        if (dashCooldown.getOrDefault(p.getUniqueId(),0L)>now) { p.sendMessage(ChatColor.RED+"Dash is cooling down."); return; }
        Vector direction=p.getLocation().getDirection().normalize();
        p.setVelocity(direction.multiply(2.6).setY(direction.getY()*2.6));
        p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 24, .4,.4,.4,.08);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, .6f, 1.7f);
        dashCooldown.put(p.getUniqueId(), now+2500);
    }
    @EventHandler public void onDamage(org.bukkit.event.entity.EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker=null; ItemStack weapon=null;
        if (e.getDamager() instanceof Player p) { attacker=p; weapon=p.getInventory().getItemInMainHand(); }
        if (attacker==null) return;
        if (isFractured(weapon)) { e.setDamage(1000); }
        else if ("emerald".equals(itemTier(weapon))) e.setDamage(e.getDamage()*1.25);
        else if ("nether".equals(itemTier(weapon))) e.setDamage(e.getDamage()*1.5);
        else if ("god".equals(itemTier(weapon))) e.setDamage(e.getDamage()*2.0);
    }
    @Override public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length==0 || args[0].equalsIgnoreCase("stats")) {
            if (!(sender instanceof Player p)) { sender.sendMessage("Use /trier stats as a player."); return true; }
            Tier t=tierFor(getKills(p)); sender.sendMessage(ChatColor.GOLD+"Kills: "+getKills(p)+" | Trier: "+t.color+t.display); return true;
        }
        if (!sender.hasPermission("trierspears.admin")) { sender.sendMessage(ChatColor.RED+"You need trierspears.admin."); return true; }
        if (args[0].equalsIgnoreCase("fractured") && args.length>=2) {
            Player target=Bukkit.getPlayerExact(args[1]); if(target==null){sender.sendMessage(ChatColor.RED+"Player not online.");return true;}
            target.getInventory().addItem(makeFractured()); target.sendMessage(ChatColor.DARK_PURPLE+"You have received The Fractured.");
            sender.sendMessage(ChatColor.GREEN+"Gave The Fractured to "+target.getName()+"."); return true;
        }
        if (args[0].equalsIgnoreCase("give") && args.length>=2) {
            Player target=Bukkit.getPlayerExact(args[1]); if(target==null){sender.sendMessage(ChatColor.RED+"Player not online.");return true;}
            target.getInventory().addItem(makeSpear(tierFor(getKills(target)))); sender.sendMessage(ChatColor.GREEN+"Gave their current Trier."); return true;
        }
        if (args[0].equalsIgnoreCase("setkills") && args.length>=3) {
            Player target=Bukkit.getPlayerExact(args[1]); if(target==null){sender.sendMessage(ChatColor.RED+"Player not online.");return true;}
            try { int amount=Math.max(0,Integer.parseInt(args[2])); kills.put(target.getUniqueId(),amount); saveKills(); giveCurrent(target); updateRank(target); sender.sendMessage(ChatColor.GREEN+"Set kills to "+amount+"."); }
            catch(NumberFormatException ex){sender.sendMessage(ChatColor.RED+"Kills must be a number.");} return true;
        }
        sender.sendMessage(ChatColor.YELLOW+"Commands: /trier stats, /trier give <player>, /trier fractured <player>, /trier setkills <player> <number>"); return true;
    }
}
