# TrierSpears (Paper 26.3)

Kill progression spear plugin for Paper 26.3 / Java 25.

## Progression
Wooden Trier (spawn) -> Stone (5 kills) -> Copper (15) -> Iron (30) -> Golden (50) -> Diamond (100) -> Emerald (175) -> Nether (250) -> God (500).
PvP kills count; kills are saved in config.yml.

## God Trier controls
- Sneak + right-click while holding the God Trier: slow nearby players within 12 blocks for 4 seconds (15-second cooldown). Owner is excluded.
- Press F (swap hands) while holding the God Trier: dash in the direction you're looking, including vertical angles (2.5-second cooldown).

## Secret spear
`/trier fractured <player>` gives The Fractured, a netherite spear that one-shots player targets. Admin/op permission `trierspears.admin`.

## Commands
- `/trier stats`
- `/trier give <player>`
- `/trier fractured <player>` (admin)
- `/trier setkills <player> <number>` (admin)

## Build
Run `gradle build` with Gradle installed. The plugin jar is in `build/libs/`.
Copy it into your Paper server `plugins/` directory and restart.
